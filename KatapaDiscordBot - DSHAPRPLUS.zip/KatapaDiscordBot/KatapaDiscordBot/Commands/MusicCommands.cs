﻿using DSharpPlus.Entities;
using DSharpPlus;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KatapaDiscordBot.Utility;

namespace KatapaDiscordBot.Commands
{
    public class MusicCommands : ApplicationCommandModule
    {
        [SlashCommand("play", "Plays Music")]
        public async Task PlayCommand(InteractionContext ctx, [Option("SongName", "Name of the Song")] string SongName)
        {
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder().WithContent("Working On It...."));

            await CommonService.JoinCurrentChannel(ctx);


            var embedMessage = new DiscordEmbedBuilder()
            {
                Title = SongName
            };

            await ctx.Channel.SendMessageAsync(embed: embedMessage);
        }
    }
}
