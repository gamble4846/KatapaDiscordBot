﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using DSharpPlus.VoiceNext;
using KatapaDiscordBot.Models;
using NAudio.Wave;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace KatapaDiscordBot.Utility
{
    public static class CommonService
    {
        public static async Task<ConfigJSONModel> GetConfigJSONObject()
        {
            var json = String.Empty;
            using (var fs = File.OpenRead("config.json"))
            using (var sr = new StreamReader(fs, new UTF8Encoding(false)))
                json = await sr.ReadToEndAsync();

            var configJson = JsonConvert.DeserializeObject<ConfigJSONModel>(json);

            return configJson;
        }

        public static async Task JoinCurrentChannel(InteractionContext ctx)
        {
            var chn = ctx.Member?.VoiceState?.Channel;

            // check whether VNext is enabled
            var vnext = ctx.Client.GetVoiceNext();
            if (vnext == null)
            {
                // not enabled
                await ctx.Channel.SendMessageAsync("VNext is not enabled or configured.");
                return;
            }

            // check whether we aren't already connected
            var vnc = vnext.GetConnection(ctx.Guild);
            if (vnc != null)
            {
                // already connected
                await ctx.Channel.SendMessageAsync("Already connected in this guild.");
                return;
            }

            // get member's voice state
            var vstat = ctx.Member?.VoiceState;
            if (vstat?.Channel == null && chn == null)
            {
                // they did not specify a channel and are not in one
                await ctx.Channel.SendMessageAsync("You are not in a voice channel.");
                return;
            }

            var voiceChannel = vstat.Channel;
            var connection = await voiceChannel.ConnectAsync();

            await ctx.Channel.SendMessageAsync($"Connected to `{chn.Name}`");
        }

    }
}
